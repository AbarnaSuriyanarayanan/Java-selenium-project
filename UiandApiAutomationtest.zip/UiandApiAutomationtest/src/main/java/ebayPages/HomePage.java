package ebayPages;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import testBase.TestBase;

public class HomePage extends TestBase {

	public HomePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
}
	
/********************************Locators******************************/
	
	@FindBy(xpath="//input[@id='gh-ac']")
	private WebElement searchBox;
	
	@FindBy(xpath="//span[text()='Search']")
	private WebElement search;
	
	@FindBy(xpath="//a[contains(@href,'//cart')]")
	private WebElement cartEbay;
	
	@FindBy(xpath="//select[@data-test-id='qty-dropdown']")
	private WebElement selectDropDown;
	
	@FindBy(xpath="//section[contains(@class,'confirmation')]")
	private WebElement confirmationMsg;

	/******************************Methods******************************/
	
	public void navigateToUrl(String currentUrl) {
		driver.get(currentUrl);
	}
	
	public void switchToWindow(int index) {
		Set<String> windows = driver.getWindowHandles() ;
		int i = 1;
		for (String window : windows) {
		if (i == index) {
		driver.switchTo().window(window);
	}else {
		i++;}}
	}
	
	public void setExplicitWait(WebElement ele, long timeOutSeconds) {
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds (timeOutSeconds));
	wait.until(ExpectedConditions.visibilityOf(ele));
	}
	
	public void clickOnSearchBox(String value) {
		setExplicitWait(searchBox, 5);
		searchBox.click();
		setExplicitWait(searchBox, 5);
		searchBox.sendKeys(value);
	}
	
	public void clickOnSearch() {
		setExplicitWait(search, 5);
		search.click();
	}
	
	public void clickOnFirstBookInList(int index) {
		setExplicitWait(driver.findElement(By.xpath("(//li[contains(@id,'item')])["+index+"]//div//a[contains(@class,'link')]")), 5);
		driver.findElement(By.xpath("(//li[contains(@id,'item')])["+index+"]//div//a[contains(@class,'link')]")).click();
	}
	
	public void selectBuyOptions(String options) {
		setExplicitWait(driver.findElement(By.xpath("//a[@data-testid='ux-call-to-action']//following::span[text()='"+options+"']")), 5);
		driver.findElement(By.xpath("//a[@data-testid='ux-call-to-action']//following::span[text()='"+options+"']")).click();
	}
		
	public String recordCartEbayItems() {
		setExplicitWait(cartEbay, 15);
		return cartEbay.getText().trim();
	}
	
	public String selectQuantity(String value) {
		setExplicitWait(selectDropDown, 5);
		Select select = new Select(selectDropDown);
		select.selectByValue(value);
		return value;
	}

	public void verifyUpdatedCartSuccessMessage(String expectedMsg) {
		setExplicitWait(confirmationMsg, 5);
		String actualMsg = confirmationMsg.getText().trim();
		System.out.println("Actual message: " + actualMsg);
		Assert.assertEquals(actualMsg, expectedMsg);
		
	}}
    /***************************End of Methods*******************************/
