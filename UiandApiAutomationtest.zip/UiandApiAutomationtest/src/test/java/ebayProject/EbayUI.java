package ebayProject;
import org.testng.Assert;
import org.testng.annotations.Test;
import ebayPages.HomePage;
import testBase.TestBase;

public class EbayUI extends TestBase {
	
	private static final String EBAY_URL = "https://www.ebay.com/";
	/*************************************************************/

    /* verify item can be added to Cart*/
	
	@Test
	public void verifyItemCanBeAddedToCart() {
		HomePage homePage = new HomePage(driver);
		/*****************************************/
		String searchItem = "Book";
        String quantity = "2";
        String buyOptions = "Add to cart";
        String successMsg = "You've updated your cart.";
        /************************************************/
		
		//Step:1 Launch browser - Navigate to ebay.com
		homePage.navigateToUrl(EBAY_URL);
		
		//Step:2 Search for book
		homePage.clickOnSearchBox(searchItem);
		
		//Step:3 Click search button 
		homePage.clickOnSearch();
		
		//Step:4 Click on the first book in the list
		//NOTE: Sometimes selected book has required option, so we can change the index to pick some other book
		homePage.clickOnFirstBookInList(1);
		homePage.switchToWindow(1);
		
		//Step:5 Select Add to cart in buy options
		homePage.selectBuyOptions(buyOptions);//<--we can pass -Buy It Now, Make offer, Add to Watchlist
		
		//Step:6 Select the quantity as 2
		String selectQuantity = homePage.selectQuantity(quantity);
		System.out.println("Record the selected Quantity in the dropdown: " + selectQuantity);

		//Step:7 Validate the success Message as You've updated your cart.
		homePage.verifyUpdatedCartSuccessMessage(successMsg);
		
		//Step:8 Record the Ebay items value after the quantity update
		String ebayItems = homePage.recordCartEbayItems();
		System.out.println("Record the ebay Items as: " + ebayItems);

		//Step:9 Verify the cart has been updated and display the number of items in the cart
		Assert.assertEquals(selectQuantity, ebayItems, "Selected Quantity does not match in the ebayItems");
	
	}}