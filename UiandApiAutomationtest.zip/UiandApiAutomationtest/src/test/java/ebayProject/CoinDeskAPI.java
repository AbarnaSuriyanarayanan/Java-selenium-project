package ebayProject;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class CoinDeskAPI {
	
	private static final String COINDESK_BPI_ENDPOINT = "https://api.coindesk.com/v1/bpi/currentprice.json";
	/*******************************************************************************************************/

	/*
	 * On the following endpoint - api.coindesk.com/v1/bpi/currentprice.json,
	 * automate the following 1. Send the GET request 2. Verify the response
	 * contains a. There are 3 BPIs i. USD ii. GBP iii. EUR b. The GBP �description�
	 * equals �British Pound Sterling�.
	 */

	@Test
	public void currentPrice() {
		RestAssured.baseURI = COINDESK_BPI_ENDPOINT;
		/************************************************************************/
                 given()   
                .when()
                .get(RestAssured.baseURI)
                .then()
                .log().all()
                .statusCode(200)
                .body("bpi.USD", notNullValue())  
                .body("bpi.GBP", notNullValue())  
                .body("bpi.EUR", notNullValue())  
                .body("bpi.GBP.description", equalTo("British Pound Sterling"));
	}}